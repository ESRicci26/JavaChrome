package com.javaricci.javachrome.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.javaricci.javachrome.controller.api.BookmarkApiController;
import com.javaricci.javachrome.dto.BookmarkDTO;
import com.javaricci.javachrome.dto.BookmarkRequest;
import com.javaricci.javachrome.service.BookmarkService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Teste de integracao (slice) da camada web de {@link BookmarkApiController},
 * validando rotas, status HTTP e serializacao JSON sem carregar o contexto
 * completo da aplicacao.
 */
@WebMvcTest(BookmarkApiController.class)
class BookmarkApiControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private BookmarkService bookmarkService;

    @Test
    void deveListarFavoritosComSucesso() throws Exception {
        BookmarkDTO dto = BookmarkDTO.builder()
                .id(1L).title("GitHub").url("https://github.com")
                .createdAt(LocalDateTime.now()).build();
        when(bookmarkService.findAll()).thenReturn(List.of(dto));

        mockMvc.perform(get("/api/bookmarks"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].title").value("GitHub"));
    }

    @Test
    void deveCriarFavoritoComSucesso() throws Exception {
        BookmarkRequest request = new BookmarkRequest("GitHub", "https://github.com", null);
        BookmarkDTO created = BookmarkDTO.builder()
                .id(1L).title("GitHub").url("https://github.com")
                .createdAt(LocalDateTime.now()).build();

        when(bookmarkService.create(any(BookmarkRequest.class))).thenReturn(created);

        mockMvc.perform(post("/api/bookmarks")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    void deveRetornarBadRequestParaUrlInvalida() throws Exception {
        BookmarkRequest request = new BookmarkRequest("Titulo", "isso-nao-e-uma-url", null);

        mockMvc.perform(post("/api/bookmarks")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }
}
