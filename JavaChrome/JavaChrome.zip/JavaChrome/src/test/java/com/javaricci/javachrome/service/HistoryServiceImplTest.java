package com.javaricci.javachrome.service;

import com.javaricci.javachrome.dto.HistoryDTO;
import com.javaricci.javachrome.dto.HistoryRequest;
import com.javaricci.javachrome.exception.ResourceNotFoundException;
import com.javaricci.javachrome.mapper.HistoryMapper;
import com.javaricci.javachrome.model.HistoryEntry;
import com.javaricci.javachrome.repository.HistoryRepository;
import com.javaricci.javachrome.service.impl.HistoryServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Testes unitarios de {@link HistoryServiceImpl}.
 */
@ExtendWith(MockitoExtension.class)
class HistoryServiceImplTest {

    @Mock
    private HistoryRepository historyRepository;

    private final HistoryMapper historyMapper = new HistoryMapper();

    private HistoryService historyService;

    @BeforeEach
    void setUp() {
        historyService = new HistoryServiceImpl(historyRepository, historyMapper);
    }

    @Test
    void deveRegistrarNovaVisitaNoHistorico() {
        HistoryRequest request = new HistoryRequest("Wikipedia", "https://www.wikipedia.org", null);
        when(historyRepository.save(any(HistoryEntry.class))).thenAnswer(invocation -> {
            HistoryEntry entry = invocation.getArgument(0);
            entry.setId(10L);
            return entry;
        });

        HistoryDTO result = historyService.register(request);

        assertThat(result.getId()).isEqualTo(10L);
        assertThat(result.getUrl()).isEqualTo("https://www.wikipedia.org");
        verify(historyRepository, times(1)).save(any(HistoryEntry.class));
    }

    @Test
    void deveLancarExcecaoAoRemoverItemInexistente() {
        when(historyRepository.existsById(5L)).thenReturn(false);

        assertThatThrownBy(() -> historyService.deleteById(5L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void deveLimparTodoOHistorico() {
        historyService.clearAll();
        verify(historyRepository, times(1)).deleteAll();
    }

    @Test
    void deveListarHistoricoOrdenadoPorDataDeVisitaDesc() {
        HistoryEntry e1 = HistoryEntry.builder().id(1L).title("A").url("https://a.com").visitedAt(LocalDateTime.now()).build();
        when(historyRepository.findAllByOrderByVisitedAtDesc()).thenReturn(List.of(e1));

        List<HistoryDTO> result = historyService.findAll();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getUrl()).isEqualTo("https://a.com");
    }
}
