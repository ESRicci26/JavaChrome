package com.javaricci.javachrome.service;

import com.javaricci.javachrome.dto.BookmarkDTO;
import com.javaricci.javachrome.dto.BookmarkRequest;
import com.javaricci.javachrome.exception.DuplicateResourceException;
import com.javaricci.javachrome.exception.ResourceNotFoundException;
import com.javaricci.javachrome.mapper.BookmarkMapper;
import com.javaricci.javachrome.model.Bookmark;
import com.javaricci.javachrome.repository.BookmarkRepository;
import com.javaricci.javachrome.service.impl.BookmarkServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Testes unitarios de {@link BookmarkServiceImpl}, usando Mockito para
 * isolar a camada de servico do banco de dados real.
 */
@ExtendWith(MockitoExtension.class)
class BookmarkServiceImplTest {

    @Mock
    private BookmarkRepository bookmarkRepository;

    private final BookmarkMapper bookmarkMapper = new BookmarkMapper();

    private BookmarkService bookmarkService;

    @BeforeEach
    void setUp() {
        bookmarkService = new BookmarkServiceImpl(bookmarkRepository, bookmarkMapper);
    }

    @Test
    void deveCriarFavoritoQuandoUrlAindaNaoExiste() {
        BookmarkRequest request = new BookmarkRequest("GitHub", "https://github.com", null);

        when(bookmarkRepository.existsByUrl(request.getUrl())).thenReturn(false);
        when(bookmarkRepository.save(any(Bookmark.class))).thenAnswer(invocation -> {
            Bookmark b = invocation.getArgument(0);
            b.setId(1L);
            return b;
        });

        BookmarkDTO result = bookmarkService.create(request);

        assertThat(result.getId()).isEqualTo(1L);
        assertThat(result.getTitle()).isEqualTo("GitHub");
        assertThat(result.getUrl()).isEqualTo("https://github.com");
        verify(bookmarkRepository, times(1)).save(any(Bookmark.class));
    }

    @Test
    void deveLancarExcecaoAoCriarFavoritoComUrlDuplicada() {
        BookmarkRequest request = new BookmarkRequest("GitHub", "https://github.com", null);
        when(bookmarkRepository.existsByUrl(request.getUrl())).thenReturn(true);

        assertThatThrownBy(() -> bookmarkService.create(request))
                .isInstanceOf(DuplicateResourceException.class);

        verify(bookmarkRepository, never()).save(any(Bookmark.class));
    }

    @Test
    void deveListarTodosOsFavoritosOrdenadosPorDataDeCriacao() {
        Bookmark b1 = Bookmark.builder().id(1L).title("A").url("https://a.com").createdAt(LocalDateTime.now()).build();
        Bookmark b2 = Bookmark.builder().id(2L).title("B").url("https://b.com").createdAt(LocalDateTime.now()).build();
        when(bookmarkRepository.findAllByOrderByCreatedAtDesc()).thenReturn(List.of(b2, b1));

        List<BookmarkDTO> result = bookmarkService.findAll();

        assertThat(result).hasSize(2);
        assertThat(result.get(0).getTitle()).isEqualTo("B");
    }

    @Test
    void deveLancarExcecaoAoRemoverFavoritoInexistente() {
        when(bookmarkRepository.existsById(anyLong())).thenReturn(false);

        assertThatThrownBy(() -> bookmarkService.deleteById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void deveRemoverFavoritoExistente() {
        when(bookmarkRepository.existsById(1L)).thenReturn(true);

        bookmarkService.deleteById(1L);

        verify(bookmarkRepository, times(1)).deleteById(1L);
    }
}
