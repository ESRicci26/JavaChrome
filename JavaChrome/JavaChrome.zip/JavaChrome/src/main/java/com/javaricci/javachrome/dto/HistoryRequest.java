package com.javaricci.javachrome.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.validator.constraints.URL;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * DTO de entrada para registrar uma nova visita no historico de navegacao.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HistoryRequest {

    @NotBlank
    @Size(max = 255)
    private String title;

    @NotBlank
    @URL(message = "Informe uma URL valida")
    @Size(max = 2048)
    private String url;

    private String faviconUrl;
}
