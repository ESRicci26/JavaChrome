package com.javaricci.javachrome.controller;

import com.javaricci.javachrome.service.ProxyService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Serve paginas externas "proxiadas": o HTML e buscado no servidor e
 * devolvido hospedado no dominio do JavaChrome, permitindo que seja exibido
 * dentro do iframe mesmo quando o site original bloqueia ser enquadrado por
 * outra origem (X-Frame-Options / CSP frame-ancestors).
 */
@Controller
@RequiredArgsConstructor
public class ProxyController {

    private final ProxyService proxyService;

    @GetMapping(value = "/proxy/view", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> view(@RequestParam String url) {
        String html = proxyService.fetchAndRewrite(url);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_TYPE, "text/html; charset=UTF-8")
                .body(html);
    }
}
