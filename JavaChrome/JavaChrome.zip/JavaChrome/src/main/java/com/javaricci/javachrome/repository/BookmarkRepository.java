package com.javaricci.javachrome.repository;

import com.javaricci.javachrome.model.Bookmark;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

/**
 * Repositorio de acesso a dados para a entidade {@link Bookmark}.
 */
public interface BookmarkRepository extends JpaRepository<Bookmark, Long> {

    boolean existsByUrl(String url);

    Optional<Bookmark> findByUrl(String url);

    List<Bookmark> findAllByOrderByCreatedAtDesc();
}
