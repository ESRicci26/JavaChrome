package com.javaricci.javachrome.service.impl;

import com.javaricci.javachrome.dto.BookmarkDTO;
import com.javaricci.javachrome.dto.BookmarkRequest;
import com.javaricci.javachrome.exception.DuplicateResourceException;
import com.javaricci.javachrome.exception.ResourceNotFoundException;
import com.javaricci.javachrome.mapper.BookmarkMapper;
import com.javaricci.javachrome.model.Bookmark;
import com.javaricci.javachrome.repository.BookmarkRepository;
import com.javaricci.javachrome.service.BookmarkService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Implementacao das regras de negocio de favoritos.
 *
 * Injecao de dependencia via construtor (gerada pelo Lombok com
 * {@code @RequiredArgsConstructor}) e a forma recomendada pelo time do
 * Spring, pois torna as dependencias explicitas e facilita testes unitarios.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class BookmarkServiceImpl implements BookmarkService {

    private final BookmarkRepository bookmarkRepository;
    private final BookmarkMapper bookmarkMapper;

    @Override
    @Transactional(readOnly = true)
    public List<BookmarkDTO> findAll() {
        return bookmarkMapper.toDTOList(bookmarkRepository.findAllByOrderByCreatedAtDesc());
    }

    @Override
    @Transactional
    public BookmarkDTO create(BookmarkRequest request) {
        if (bookmarkRepository.existsByUrl(request.getUrl())) {
            throw new DuplicateResourceException("Esta URL ja esta nos favoritos: " + request.getUrl());
        }

        Bookmark bookmark = Bookmark.builder()
                .title(request.getTitle())
                .url(request.getUrl())
                .faviconUrl(request.getFaviconUrl())
                .createdAt(LocalDateTime.now())
                .build();

        Bookmark saved = bookmarkRepository.save(bookmark);
        log.info("Favorito criado: {} ({})", saved.getTitle(), saved.getUrl());
        return bookmarkMapper.toDTO(saved);
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        if (!bookmarkRepository.existsById(id)) {
            throw new ResourceNotFoundException("Favorito nao encontrado com id: " + id);
        }
        bookmarkRepository.deleteById(id);
        log.info("Favorito removido: id={}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existsByUrl(String url) {
        return bookmarkRepository.existsByUrl(url);
    }
}
