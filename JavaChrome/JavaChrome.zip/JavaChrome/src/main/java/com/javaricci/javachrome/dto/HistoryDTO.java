package com.javaricci.javachrome.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DTO utilizado para expor dados de {@code HistoryEntry} nas respostas da API.
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HistoryDTO {
    private Long id;
    private String title;
    private String url;
    private String faviconUrl;
    private LocalDateTime visitedAt;
}
