package com.javaricci.javachrome.service.impl;

import com.javaricci.javachrome.dto.HistoryDTO;
import com.javaricci.javachrome.dto.HistoryRequest;
import com.javaricci.javachrome.exception.ResourceNotFoundException;
import com.javaricci.javachrome.mapper.HistoryMapper;
import com.javaricci.javachrome.model.HistoryEntry;
import com.javaricci.javachrome.repository.HistoryRepository;
import com.javaricci.javachrome.service.HistoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Implementacao das regras de negocio do historico de navegacao.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class HistoryServiceImpl implements HistoryService {

    private final HistoryRepository historyRepository;
    private final HistoryMapper historyMapper;

    @Override
    @Transactional(readOnly = true)
    public List<HistoryDTO> findAll() {
        return historyMapper.toDTOList(historyRepository.findAllByOrderByVisitedAtDesc());
    }

    @Override
    @Transactional(readOnly = true)
    public List<HistoryDTO> findRecent(int limit) {
        return historyMapper.toDTOList(
                historyRepository.findAllByOrderByVisitedAtDesc(PageRequest.of(0, limit)));
    }

    @Override
    @Transactional
    public HistoryDTO register(HistoryRequest request) {
        HistoryEntry entry = HistoryEntry.builder()
                .title(request.getTitle())
                .url(request.getUrl())
                .faviconUrl(request.getFaviconUrl())
                .visitedAt(LocalDateTime.now())
                .build();

        HistoryEntry saved = historyRepository.save(entry);
        log.debug("Visita registrada no historico: {}", saved.getUrl());
        return historyMapper.toDTO(saved);
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        if (!historyRepository.existsById(id)) {
            throw new ResourceNotFoundException("Item de historico nao encontrado com id: " + id);
        }
        historyRepository.deleteById(id);
    }

    @Override
    @Transactional
    public void clearAll() {
        historyRepository.deleteAll();
        log.info("Historico de navegacao limpo por completo");
    }
}
