package com.javaricci.javachrome.service;

import com.javaricci.javachrome.dto.HistoryDTO;
import com.javaricci.javachrome.dto.HistoryRequest;

import java.util.List;

/**
 * Regras de negocio relacionadas ao historico de navegacao.
 */
public interface HistoryService {

    List<HistoryDTO> findAll();

    List<HistoryDTO> findRecent(int limit);

    HistoryDTO register(HistoryRequest request);

    void deleteById(Long id);

    void clearAll();
}
