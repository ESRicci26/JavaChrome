package com.javaricci.javachrome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Ponto de entrada da aplicacao JavaChrome.
 *
 * JavaChrome e um navegador web construido inteiramente com tecnologias Java:
 * o "chrome" (casca/interface) da aplicacao - abas, barra de endereco, favoritos
 * e historico - e renderizado no servidor com Spring Boot + Thymeleaf, enquanto
 * o conteudo das paginas visitadas e carregado no navegador do usuario atraves
 * de iframes controlados por JavaScript.
 *
 * @author javaricci
 */
@SpringBootApplication
public class JavaChromeApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavaChromeApplication.class, args);
    }
}
