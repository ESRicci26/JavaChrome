package com.javaricci.javachrome.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Propriedades de configuracao do navegador JavaChrome, carregadas a partir
 * do prefixo "javachrome" em application.yml. Externalizar essas configuracoes
 * evita "magic strings" espalhadas pelo codigo (boa pratica de arquitetura).
 */
@ConfigurationProperties(prefix = "javachrome")
@Getter
@Setter
public class JavaChromeProperties {

    /** Nome exibido do navegador. */
    private String browserName = "JavaChrome";

    /** URL aberta por padrao em uma nova aba/pagina inicial. */
    private String defaultHomeUrl = "https://www.wikipedia.org";

    /** Template da URL do motor de busca; "{query}" e substituido pelo termo pesquisado. */
    private String searchEngineUrlTemplate = "https://duckduckgo.com/html/?q={query}";

    /** Tempo maximo (ms) para buscar metadados (titulo/favicon) de uma pagina. */
    private int pageMetadataTimeoutMs = 4000;
}
