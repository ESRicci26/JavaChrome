package com.javaricci.javachrome.controller;

import com.javaricci.javachrome.config.JavaChromeProperties;
import com.javaricci.javachrome.service.BookmarkService;
import com.javaricci.javachrome.service.HistoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller responsavel por renderizar a "casca" (shell) do navegador
 * JavaChrome: barra de abas, barra de endereco e a pagina de nova aba.
 */
@Controller
@RequiredArgsConstructor
public class BrowserController {

    private final BookmarkService bookmarkService;
    private final HistoryService historyService;
    private final JavaChromeProperties properties;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("browserName", properties.getBrowserName());
        model.addAttribute("defaultHomeUrl", properties.getDefaultHomeUrl());
        model.addAttribute("bookmarks", bookmarkService.findAll());
        model.addAttribute("recentHistory", historyService.findRecent(8));
        return "index";
    }
}
