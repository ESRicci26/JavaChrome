package com.javaricci.javachrome.controller;

import com.javaricci.javachrome.config.JavaChromeProperties;
import com.javaricci.javachrome.service.BookmarkService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller responsavel pela pagina completa de gerenciamento de favoritos
 * (equivalente ao chrome://bookmarks do Google Chrome).
 */
@Controller
@RequiredArgsConstructor
public class BookmarkPageController {

    private final BookmarkService bookmarkService;
    private final JavaChromeProperties properties;

    @GetMapping("/bookmarks")
    public String bookmarksPage(Model model) {
        model.addAttribute("browserName", properties.getBrowserName());
        model.addAttribute("bookmarks", bookmarkService.findAll());
        return "bookmarks";
    }
}
