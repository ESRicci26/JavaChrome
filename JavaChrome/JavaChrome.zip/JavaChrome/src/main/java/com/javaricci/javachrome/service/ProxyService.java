package com.javaricci.javachrome.service;

/**
 * Busca uma pagina externa no servidor e a devolve reescrita para ser
 * exibida dentro de um iframe hospedado no dominio do JavaChrome.
 *
 * Isso contorna a restricao de "X-Frame-Options" / "Content-Security-Policy:
 * frame-ancestors" que muitos sites usam para impedir de serem exibidos em
 * um iframe de OUTRA origem: como o JavaChrome busca o HTML no servidor e
 * devolve como conteudo proprio (sem repassar aqueles cabecalhos), o
 * navegador do usuario passa a tratar a pagina como pertencente ao dominio
 * do JavaChrome.
 */
public interface ProxyService {

    /**
     * @param url URL absoluta da pagina a ser buscada
     * @return HTML reescrito, pronto para ser servido pelo JavaChrome
     */
    String fetchAndRewrite(String url);
}
