package com.javaricci.javachrome.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DTO utilizado para expor dados de {@code Bookmark} nas respostas da API,
 * evitando expor a entidade JPA diretamente na camada web.
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookmarkDTO {
    private Long id;
    private String title;
    private String url;
    private String faviconUrl;
    private LocalDateTime createdAt;
}
