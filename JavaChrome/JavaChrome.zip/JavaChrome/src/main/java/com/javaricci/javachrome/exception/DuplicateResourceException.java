package com.javaricci.javachrome.exception;

/**
 * Lancada quando se tenta criar um recurso que ja existe (ex: favoritar uma
 * URL que ja esta na lista de favoritos).
 */
public class DuplicateResourceException extends RuntimeException {

    public DuplicateResourceException(String message) {
        super(message);
    }
}
