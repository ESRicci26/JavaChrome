package com.javaricci.javachrome.controller.api;

import com.javaricci.javachrome.dto.HistoryDTO;
import com.javaricci.javachrome.dto.HistoryRequest;
import com.javaricci.javachrome.service.HistoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * API REST para o historico de navegacao, consumida via AJAX pelo frontend.
 */
@RestController
@RequestMapping("/api/history")
@RequiredArgsConstructor
public class HistoryApiController {

    private final HistoryService historyService;

    @GetMapping
    public ResponseEntity<List<HistoryDTO>> findAll(
            @RequestParam(required = false) Integer limit) {
        if (limit != null) {
            return ResponseEntity.ok(historyService.findRecent(limit));
        }
        return ResponseEntity.ok(historyService.findAll());
    }

    @PostMapping
    public ResponseEntity<HistoryDTO> register(@Valid @RequestBody HistoryRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(historyService.register(request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        historyService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping
    public ResponseEntity<Void> clearAll() {
        historyService.clearAll();
        return ResponseEntity.noContent().build();
    }
}
