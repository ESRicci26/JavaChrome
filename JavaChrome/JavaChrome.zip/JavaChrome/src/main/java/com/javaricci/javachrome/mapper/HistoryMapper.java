package com.javaricci.javachrome.mapper;

import com.javaricci.javachrome.dto.HistoryDTO;
import com.javaricci.javachrome.model.HistoryEntry;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Conversor entre a entidade {@link HistoryEntry} e o {@link HistoryDTO}.
 */
@Component
public class HistoryMapper {

    public HistoryDTO toDTO(HistoryEntry entry) {
        return HistoryDTO.builder()
                .id(entry.getId())
                .title(entry.getTitle())
                .url(entry.getUrl())
                .faviconUrl(entry.getFaviconUrl())
                .visitedAt(entry.getVisitedAt())
                .build();
    }

    public List<HistoryDTO> toDTOList(List<HistoryEntry> entries) {
        return entries.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }
}
