package com.javaricci.javachrome.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Representa uma entrada no historico de navegacao do JavaChrome.
 */
@Entity
@Table(name = "history_entries")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HistoryEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 255)
    private String title;

    @Column(nullable = false, length = 2048)
    private String url;

    @Column(name = "favicon_url", length = 2048)
    private String faviconUrl;

    @Column(name = "visited_at", nullable = false)
    private LocalDateTime visitedAt;
}
