package com.javaricci.javachrome.controller.api;

import com.javaricci.javachrome.dto.BookmarkDTO;
import com.javaricci.javachrome.dto.BookmarkRequest;
import com.javaricci.javachrome.service.BookmarkService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * API REST para gerenciamento de favoritos, consumida via AJAX pelo
 * frontend (Thymeleaf + JavaScript) do JavaChrome.
 */
@RestController
@RequestMapping("/api/bookmarks")
@RequiredArgsConstructor
public class BookmarkApiController {

    private final BookmarkService bookmarkService;

    @GetMapping
    public ResponseEntity<List<BookmarkDTO>> findAll() {
        return ResponseEntity.ok(bookmarkService.findAll());
    }

    @GetMapping("/exists")
    public ResponseEntity<Map<String, Boolean>> exists(@RequestParam String url) {
        return ResponseEntity.ok(Map.of("exists", bookmarkService.existsByUrl(url)));
    }

    @PostMapping
    public ResponseEntity<BookmarkDTO> create(@Valid @RequestBody BookmarkRequest request) {
        BookmarkDTO created = bookmarkService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        bookmarkService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
