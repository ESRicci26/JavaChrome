package com.javaricci.javachrome.repository;

import com.javaricci.javachrome.model.HistoryEntry;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Repositorio de acesso a dados para a entidade {@link HistoryEntry}.
 */
public interface HistoryRepository extends JpaRepository<HistoryEntry, Long> {

    List<HistoryEntry> findAllByOrderByVisitedAtDesc(Pageable pageable);

    List<HistoryEntry> findAllByOrderByVisitedAtDesc();
}
