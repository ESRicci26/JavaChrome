package com.javaricci.javachrome.exception;

/**
 * Lancada quando um recurso (favorito, item de historico, etc.) solicitado
 * nao e encontrado.
 */
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
