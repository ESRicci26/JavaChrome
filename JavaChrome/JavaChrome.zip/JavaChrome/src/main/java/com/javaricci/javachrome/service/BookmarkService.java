package com.javaricci.javachrome.service;

import com.javaricci.javachrome.dto.BookmarkDTO;
import com.javaricci.javachrome.dto.BookmarkRequest;

import java.util.List;

/**
 * Regras de negocio relacionadas aos favoritos do navegador.
 */
public interface BookmarkService {

    List<BookmarkDTO> findAll();

    BookmarkDTO create(BookmarkRequest request);

    void deleteById(Long id);

    boolean existsByUrl(String url);
}
