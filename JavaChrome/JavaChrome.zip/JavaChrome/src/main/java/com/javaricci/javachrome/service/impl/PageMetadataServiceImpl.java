package com.javaricci.javachrome.service.impl;

import com.javaricci.javachrome.config.JavaChromeProperties;
import com.javaricci.javachrome.dto.PageMetadata;
import com.javaricci.javachrome.service.PageMetadataService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Implementacao que busca titulo e favicon de uma pagina usando Jsoup.
 *
 * Falhas de rede, timeout ou paginas que bloqueiam scraping nao devem
 * derrubar a aplicacao: nesses casos devolvemos um metadado "de reserva"
 * (fallback) baseado apenas no host da URL, para que a aba do navegador
 * sempre tenha algo razoavel para exibir.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PageMetadataServiceImpl implements PageMetadataService {

    private static final String DEFAULT_FAVICON = "/images/default-favicon.svg";

    private final JavaChromeProperties properties;

    @Override
    public PageMetadata fetchMetadata(String url) {
        try {
            Document document = Jsoup.connect(url)
                    .timeout(properties.getPageMetadataTimeoutMs())
                    .userAgent("Mozilla/5.0 (compatible; JavaChrome/1.0; +https://github.com/javaricci)")
                    .followRedirects(true)
                    .get();

            String title = extractTitle(document, url);
            String favicon = extractFavicon(document, url);

            return PageMetadata.builder()
                    .url(url)
                    .title(title)
                    .faviconUrl(favicon)
                    .build();

        } catch (Exception e) {
            log.warn("Nao foi possivel obter metadados de {}: {}", url, e.getMessage());
            return fallbackMetadata(url);
        }
    }

    private String extractTitle(Document document, String url) {
        String title = document.title();
        if (title == null || title.isBlank()) {
            return extractHost(url);
        }
        return title.trim();
    }

    private String extractFavicon(Document document, String url) {
        Element iconLink = document.selectFirst("link[rel~=(?i)^(shortcut icon|icon)$]");
        if (iconLink != null) {
            String href = iconLink.absUrl("href");
            if (!href.isBlank()) {
                return href;
            }
        }
        try {
            URL parsed = new URL(url);
            return parsed.getProtocol() + "://" + parsed.getHost() + "/favicon.ico";
        } catch (MalformedURLException e) {
            return DEFAULT_FAVICON;
        }
    }

    private PageMetadata fallbackMetadata(String url) {
        return PageMetadata.builder()
                .url(url)
                .title(extractHost(url))
                .faviconUrl(DEFAULT_FAVICON)
                .build();
    }

    private String extractHost(String url) {
        try {
            return new URL(url).getHost();
        } catch (MalformedURLException e) {
            return url;
        }
    }
}
