package com.javaricci.javachrome.mapper;

import com.javaricci.javachrome.dto.BookmarkDTO;
import com.javaricci.javachrome.model.Bookmark;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Conversor entre a entidade {@link Bookmark} e o {@link BookmarkDTO}.
 * Manter essa conversao isolada evita que a entidade JPA "escape" para a
 * camada de apresentacao/API.
 */
@Component
public class BookmarkMapper {

    public BookmarkDTO toDTO(Bookmark bookmark) {
        return BookmarkDTO.builder()
                .id(bookmark.getId())
                .title(bookmark.getTitle())
                .url(bookmark.getUrl())
                .faviconUrl(bookmark.getFaviconUrl())
                .createdAt(bookmark.getCreatedAt())
                .build();
    }

    public List<BookmarkDTO> toDTOList(List<Bookmark> bookmarks) {
        return bookmarks.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }
}
