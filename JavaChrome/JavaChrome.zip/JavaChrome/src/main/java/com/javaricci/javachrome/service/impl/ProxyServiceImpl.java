package com.javaricci.javachrome.service.impl;

import com.javaricci.javachrome.config.JavaChromeProperties;
import com.javaricci.javachrome.service.ProxyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.HttpStatusException;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Implementacao de {@link ProxyService} baseada em Jsoup.
 *
 * Limitacoes conhecidas desta tecnica (inerentes, nao sao bugs):
 * <ul>
 *   <li>Sessoes/cookies do usuario no site original NAO sao levados: a
 *       pagina e sempre buscada de forma anonima/publica.</li>
 *   <li>Aplicacoes de pagina unica (SPA) que dependem de JavaScript para
 *       renderizar o conteudo principal podem aparecer incompletas, pois o
 *       Jsoup nao executa JavaScript.</li>
 *   <li>Sites protegidos por WAF/anti-bot (Cloudflare, Akamai, captcha) podem
 *       recusar a requisicao do servidor, mesmo com User-Agent de navegador.</li>
 *   <li>Formularios de busca do site original nao sao reescritos (apenas
 *       links "a href"), entao e melhor usar a barra de endereco do proprio
 *       JavaChrome para pesquisar.</li>
 * </ul>
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ProxyServiceImpl implements ProxyService {

    private static final List<String> SKIP_HREF_PREFIXES =
            List.of("javascript:", "mailto:", "tel:", "#");

    private final JavaChromeProperties properties;

    @Override
    public String fetchAndRewrite(String url) {
        try {
            Document document = Jsoup.connect(url)
                    .timeout(properties.getPageMetadataTimeoutMs() * 3)
                    .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                            + "(KHTML, like Gecko) Chrome/125.0 Safari/537.36")
                    .header("Accept-Language", "pt-BR,pt;q=0.9,en;q=0.8")
                    .followRedirects(true)
                    .maxBodySize(6 * 1024 * 1024)
                    .get();

            insertBaseTag(document);
            stripFrameBlockingMeta(document);
            rewriteAnchors(document);

            return document.outerHtml();

        } catch (SocketTimeoutException e) {
            log.warn("Timeout ao carregar via proxy '{}'", url);
            return errorPage(url, "O site demorou demais para responder.");
        } catch (HttpStatusException e) {
            log.warn("Site respondeu com status {} para '{}'", e.getStatusCode(), url);
            return errorPage(url, "O site respondeu com erro HTTP " + e.getStatusCode()
                    + " (pode estar bloqueando acessos automatizados).");
        } catch (IOException e) {
            log.warn("Falha de rede ao carregar via proxy '{}': {}", url, e.getMessage());
            return errorPage(url, "Nao foi possivel conectar a esse site.");
        } catch (Exception e) {
            log.error("Erro inesperado no proxy para '{}'", url, e);
            return errorPage(url, "Ocorreu um erro inesperado ao carregar a pagina.");
        }
    }

    private void insertBaseTag(Document document) {
        if (document.head().selectFirst("base") == null) {
            document.head().prependElement("base").attr("href", document.baseUri());
        }
    }

    private void stripFrameBlockingMeta(Document document) {
        document.select(
                "meta[http-equiv=Content-Security-Policy], meta[http-equiv=content-security-policy]"
        ).remove();
    }

    /**
     * Reescreve todos os links da pagina para que continuem passando pelo
     * proxy do JavaChrome (senao, ao clicar num link, o iframe navegaria
     * direto para o site original e voltaria a sofrer o bloqueio de
     * enquadramento). Tambem remove o atributo "target" para impedir que o
     * link tente "escapar" do iframe (target=_top/_parent).
     */
    private void rewriteAnchors(Document document) {
        for (Element anchor : document.select("a[href]")) {
            String rawHref = anchor.attr("href").trim();
            if (rawHref.isEmpty() || startsWithAny(rawHref)) {
                continue;
            }
            String absoluteHref = anchor.absUrl("href");
            if (absoluteHref.isBlank()) {
                continue;
            }
            anchor.attr("href", "/proxy/view?url=" + URLEncoder.encode(absoluteHref, StandardCharsets.UTF_8));
            anchor.removeAttr("target");
        }
    }

    private boolean startsWithAny(String value) {
        String lower = value.toLowerCase();
        return SKIP_HREF_PREFIXES.stream().anyMatch(lower::startsWith);
    }

    private String errorPage(String url, String reason) {
        String safeUrl = url == null ? "" : url.replace("\"", "&quot;");
        return "<html data-jc-proxy-error=\"1\"><head><meta charset=\"utf-8\"></head>"
                + "<body style=\"font-family:sans-serif;padding:40px;color:#5f6368;\">"
                + "<h2 style=\"color:#202124;margin-bottom:8px;\">Nao foi possivel carregar esta pagina</h2>"
                + "<p>" + escape(reason) + "</p>"
                + "<p><a href=\"" + safeUrl + "\" target=\"_blank\" rel=\"noopener\">"
                + "Tentar abrir em uma nova aba do seu navegador real</a></p>"
                + "</body></html>";
    }

    private String escape(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
