package com.javaricci.javachrome.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.validator.constraints.URL;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * DTO de entrada para criacao de um novo favorito, com validacao de dados
 * na borda da aplicacao (fail-fast).
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BookmarkRequest {

    @NotBlank(message = "O titulo do favorito nao pode ficar vazio")
    @Size(max = 255, message = "O titulo deve ter no maximo 255 caracteres")
    private String title;

    @NotBlank(message = "A URL do favorito nao pode ficar vazia")
    @URL(message = "Informe uma URL valida")
    @Size(max = 2048)
    private String url;

    private String faviconUrl;
}
