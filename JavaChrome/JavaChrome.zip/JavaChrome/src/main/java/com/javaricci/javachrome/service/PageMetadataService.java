package com.javaricci.javachrome.service;

import com.javaricci.javachrome.dto.PageMetadata;

/**
 * Servico responsavel por descobrir titulo e favicon de uma pagina web,
 * usado para exibir a aba corretamente (com titulo real, nao apenas a URL).
 */
public interface PageMetadataService {

    PageMetadata fetchMetadata(String url);
}
