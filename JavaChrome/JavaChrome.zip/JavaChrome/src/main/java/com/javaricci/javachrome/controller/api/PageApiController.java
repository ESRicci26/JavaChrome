package com.javaricci.javachrome.controller.api;

import com.javaricci.javachrome.config.JavaChromeProperties;
import com.javaricci.javachrome.dto.PageMetadata;
import com.javaricci.javachrome.service.PageMetadataService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriUtils;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * API REST auxiliar de navegacao: resolucao de metadados de pagina e
 * construcao de URLs de busca a partir do texto digitado na barra de
 * endereco (omnibox).
 */
@RestController
@RequestMapping("/api/page")
@RequiredArgsConstructor
public class PageApiController {

    private static final Pattern URL_LIKE = Pattern.compile(
            "^(https?://)?([\\w-]+\\.)+[a-z]{2,}(:\\d+)?([/?#].*)?$",
            Pattern.CASE_INSENSITIVE);

    private final PageMetadataService pageMetadataService;
    private final JavaChromeProperties properties;

    /**
     * Retorna titulo e favicon de uma URL, usado para atualizar a aba apos
     * o carregamento do iframe (o JS do cliente nao pode ler o conteudo de
     * um iframe cross-origin diretamente).
     */
    @GetMapping("/metadata")
    public ResponseEntity<PageMetadata> metadata(@RequestParam String url) {
        return ResponseEntity.ok(pageMetadataService.fetchMetadata(url));
    }

    /**
     * Recebe o texto digitado na barra de endereco e devolve a URL final de
     * navegacao: se parecer uma URL, normaliza (adicionando https://); caso
     * contrario, monta uma URL de busca no motor de busca configurado.
     */
    @GetMapping("/resolve")
    public ResponseEntity<Map<String, String>> resolve(@RequestParam String query) {
        String trimmed = query.trim();
        String resolvedUrl;

        if (URL_LIKE.matcher(trimmed).matches()) {
            resolvedUrl = trimmed.startsWith("http://") || trimmed.startsWith("https://")
                    ? trimmed
                    : "https://" + trimmed;
        } else {
            String encoded = UriUtils.encodeQueryParam(trimmed, StandardCharsets.UTF_8);
            resolvedUrl = properties.getSearchEngineUrlTemplate().replace("{query}", encoded);
        }

        return ResponseEntity.ok(Map.of("url", resolvedUrl));
    }
}
