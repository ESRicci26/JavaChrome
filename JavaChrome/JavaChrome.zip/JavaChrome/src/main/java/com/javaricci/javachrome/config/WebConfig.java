package com.javaricci.javachrome.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Configuracao geral da camada web da aplicacao.
 */
@Configuration
@EnableConfigurationProperties(JavaChromeProperties.class)
public class WebConfig {
}
