package com.javaricci.javachrome.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Metadados de uma pagina web (titulo e icone), obtidos no backend.
 *
 * Por que isso existe no servidor e nao no JavaScript do cliente? Porque, por
 * politica de seguranca do proprio navegador do usuario (Same-Origin Policy),
 * o JavaScript da aplicacao NAO consegue ler o conteudo de um iframe que
 * aponta para um dominio diferente. Por isso o JavaChrome busca esses dados
 * no servidor (via Jsoup) e os retorna para atualizar o titulo/icone da aba.
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PageMetadata {
    private String url;
    private String title;
    private String faviconUrl;
}
