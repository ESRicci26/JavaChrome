package com.javaricci.javachrome.config;

import com.javaricci.javachrome.model.Bookmark;
import com.javaricci.javachrome.repository.BookmarkRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Popula o banco H2 com alguns favoritos padrao na primeira execucao,
 * para que a pagina de nova aba do JavaChrome nao comece vazia.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final BookmarkRepository bookmarkRepository;

    @Override
    public void run(String... args) {
        if (bookmarkRepository.count() > 0) {
            return;
        }

        List<Bookmark> defaults = List.of(
                bookmark("Wikipedia", "https://www.wikipedia.org", "https://www.wikipedia.org/static/favicon/wikipedia.ico"),
                bookmark("GitHub", "https://github.com", "https://github.com/favicon.ico"),
                bookmark("Spring", "https://spring.io", "https://spring.io/favicon.ico"),
                bookmark("DuckDuckGo", "https://duckduckgo.com", "https://duckduckgo.com/favicon.ico")
        );

        bookmarkRepository.saveAll(defaults);
        log.info("Favoritos padrao criados: {}", defaults.size());
    }

    private Bookmark bookmark(String title, String url, String favicon) {
        return Bookmark.builder()
                .title(title)
                .url(url)
                .faviconUrl(favicon)
                .createdAt(LocalDateTime.now())
                .build();
    }
}
