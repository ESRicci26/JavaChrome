package com.javaricci.javachrome.controller;

import com.javaricci.javachrome.config.JavaChromeProperties;
import com.javaricci.javachrome.service.HistoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller responsavel pela pagina completa de historico de navegacao
 * (equivalente ao chrome://history do Google Chrome).
 */
@Controller
@RequiredArgsConstructor
public class HistoryPageController {

    private final HistoryService historyService;
    private final JavaChromeProperties properties;

    @GetMapping("/history")
    public String historyPage(Model model) {
        model.addAttribute("browserName", properties.getBrowserName());
        model.addAttribute("historyEntries", historyService.findAll());
        return "history";
    }
}
