/**
 * Logica da pagina completa de historico (/history).
 */
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-remove-history]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.removeHistory;
            const item = btn.closest('.jc-list-item');

            JavaChromeApi.removeHistoryEntry(id)
                .then(() => {
                    item.remove();
                    updateEmptyState();
                })
                .catch((err) => alert('Erro ao remover item do historico: ' + err.message));
        });
    });

    const clearBtn = document.getElementById('clear-history-btn');
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (!confirm('Isso vai apagar todo o historico de navegacao. Continuar?')) return;
            JavaChromeApi.clearHistory().then(() => window.location.reload());
        });
    }

    function updateEmptyState() {
        const list = document.getElementById('history-list');
        if (list && list.children.length === 0) {
            document.getElementById('empty-state').style.display = 'block';
        }
    }
});
