/**
 * Cliente HTTP simples para conversar com a API REST do JavaChrome.
 * Centralizar as chamadas fetch aqui evita duplicacao de codigo e facilita
 * manutencao (DRY - Don't Repeat Yourself).
 */
const JavaChromeApi = (() => {

    async function request(url, options = {}) {
        const response = await fetch(url, {
            headers: { 'Content-Type': 'application/json' },
            ...options,
        });

        if (!response.ok && response.status !== 204) {
            const body = await response.json().catch(() => ({}));
            throw new Error(body.message || `Erro na requisicao (${response.status})`);
        }

        if (response.status === 204) {
            return null;
        }
        return response.json();
    }

    return {
        // Metadados de pagina / resolucao da omnibox
        fetchMetadata: (url) => request(`/api/page/metadata?url=${encodeURIComponent(url)}`),
        resolveQuery: (query) => request(`/api/page/resolve?query=${encodeURIComponent(query)}`),

        // Favoritos
        getBookmarks: () => request('/api/bookmarks'),
        bookmarkExists: (url) => request(`/api/bookmarks/exists?url=${encodeURIComponent(url)}`),
        addBookmark: (payload) => request('/api/bookmarks', { method: 'POST', body: JSON.stringify(payload) }),
        removeBookmark: (id) => request(`/api/bookmarks/${id}`, { method: 'DELETE' }),

        // Historico
        getHistory: (limit) => request(`/api/history${limit ? `?limit=${limit}` : ''}`),
        addHistory: (payload) => request('/api/history', { method: 'POST', body: JSON.stringify(payload) }),
        removeHistoryEntry: (id) => request(`/api/history/${id}`, { method: 'DELETE' }),
        clearHistory: () => request('/api/history', { method: 'DELETE' }),
    };
})();
