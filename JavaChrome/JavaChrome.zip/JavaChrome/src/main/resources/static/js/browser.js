/**
 * Controla a "casca" do navegador: toolbar (voltar/avancar/recarregar),
 * barra de endereco (omnibox), menu suspenso, banner de aviso e a pagina
 * de nova aba. Delega o controle de abas propriamente dito ao TabManager.
 *
 * Observacao: a deteccao de "site bloqueado" NAO e mais feita por heuristica
 * de timeout aqui. Como toda navegacao passa pelo proxy do backend
 * ("/proxy/view"), o iframe e sempre same-origin com esta aplicacao, e o
 * TabManager consegue verificar diretamente (via
 * doc.documentElement.hasAttribute('data-jc-proxy-error')) se o backend
 * devolveu uma pagina de erro, chamando showBlockedBanner()/hideBlockedBanner()
 * de forma precisa e imediata.
 */
const BrowserChrome = (() => {

    const els = {};
    let bookmarksCache = [];

    function init() {
        cacheElements();
        bindToolbarEvents();
        loadBookmarksCache();
        TabManager.createTab(); // primeira aba abre na pagina de nova aba
    }

    function cacheElements() {
        els.omnibox = document.getElementById('omnibox');
        els.btnBack = document.getElementById('btn-back');
        els.btnForward = document.getElementById('btn-forward');
        els.btnReload = document.getElementById('btn-reload');
        els.btnStar = document.getElementById('btn-star');
        els.btnMenu = document.getElementById('btn-menu');
        els.menuDropdown = document.getElementById('menu-dropdown');
        els.btnNewTab = document.getElementById('new-tab-btn');
        els.banner = document.getElementById('banner');
        els.bannerClose = document.getElementById('banner-close');
        els.omniboxForm = document.getElementById('omnibox-form');
    }

    function bindToolbarEvents() {
        els.btnNewTab.addEventListener('click', () => TabManager.createTab());

        els.btnBack.addEventListener('click', () => {
            const tab = TabManager.getActiveTab();
            if (tab) TabManager.goBack(tab.id);
        });
        els.btnForward.addEventListener('click', () => {
            const tab = TabManager.getActiveTab();
            if (tab) TabManager.goForward(tab.id);
        });
        els.btnReload.addEventListener('click', () => {
            const tab = TabManager.getActiveTab();
            if (tab) TabManager.reload(tab.id);
        });

        els.omniboxForm.addEventListener('submit', (evt) => {
            evt.preventDefault();
            goToOmniboxValue();
        });

        els.btnStar.addEventListener('click', toggleBookmarkForActiveTab);

        els.btnMenu.addEventListener('click', (evt) => {
            evt.stopPropagation();
            els.menuDropdown.classList.toggle('open');
        });
        document.addEventListener('click', () => els.menuDropdown.classList.remove('open'));

        els.bannerClose.addEventListener('click', hideBlockedBanner);
    }

    function goToOmniboxValue() {
        const value = els.omnibox.value.trim();
        const tab = TabManager.getActiveTab();
        if (!tab || !value) return;

        JavaChromeApi.resolveQuery(value)
            .then(({ url }) => TabManager.navigate(tab.id, url))
            .catch((err) => console.error('Falha ao resolver endereco:', err));
    }

    function showBlockedBanner() {
        els.banner.classList.add('show');
    }

    function hideBlockedBanner() {
        els.banner.classList.remove('show');
    }

    function toggleBookmarkForActiveTab() {
        const tab = TabManager.getActiveTab();
        if (!tab || !tab.url) return;

        const existing = bookmarksCache.find((b) => b.url === tab.url);
        if (existing) {
            JavaChromeApi.removeBookmark(existing.id).then(() => {
                bookmarksCache = bookmarksCache.filter((b) => b.id !== existing.id);
                updateStarButton(tab);
            });
        } else {
            JavaChromeApi.addBookmark({ title: tab.title, url: tab.url, faviconUrl: tab.favicon })
                .then((created) => {
                    bookmarksCache.push(created);
                    updateStarButton(tab);
                })
                .catch((err) => alert(err.message));
        }
    }

    function updateStarButton(tab) {
        const isBookmarked = !!tab.url && bookmarksCache.some((b) => b.url === tab.url);
        els.btnStar.classList.toggle('active', isBookmarked);
    }

    function loadBookmarksCache() {
        JavaChromeApi.getBookmarks()
            .then((list) => { bookmarksCache = list; })
            .catch((err) => console.warn('Nao foi possivel carregar favoritos:', err));
    }

    /** Chamado pelo TabManager sempre que a aba ativa muda ou e atualizada. */
    function onActiveTabChanged(tab) {
        els.omnibox.value = tab.url || '';
        els.btnBack.disabled = !TabManager.canGoBack(tab);
        els.btnForward.disabled = !TabManager.canGoForward(tab);
        updateStarButton(tab);
        if (!tab.url) hideBlockedBanner();
    }

    /** Conecta a busca e os atalhos de favoritos da pagina de nova aba de uma aba especifica. */
    function initNewTabPage(tab) {
        const form = tab.newtabEl.querySelector('.jc-newtab-search-form');
        const input = form.querySelector('input');
        const shortcutsEl = tab.newtabEl.querySelector('.jc-shortcuts');

        form.addEventListener('submit', (evt) => {
            evt.preventDefault();
            const value = input.value.trim();
            if (!value) return;
            JavaChromeApi.resolveQuery(value).then(({ url }) => TabManager.navigate(tab.id, url));
        });

        renderShortcuts(shortcutsEl, tab);
    }

    function renderShortcuts(container, tab) {
        const render = (bookmarks) => {
            container.innerHTML = '';
            bookmarks.slice(0, 10).forEach((bm) => {
                const a = document.createElement('a');
                a.href = 'javascript:void(0)';
                a.className = 'jc-shortcut';
                a.innerHTML = `
                    <span class="jc-shortcut-icon">${
                        bm.faviconUrl
                            ? `<img src="${bm.faviconUrl}" alt="" onerror="this.remove()"/>`
                            : bm.title.charAt(0).toUpperCase()
                    }</span>
                    <span>${bm.title}</span>`;
                a.addEventListener('click', () => TabManager.navigate(tab.id, bm.url));
                container.appendChild(a);
            });
        };

        if (bookmarksCache.length) {
            render(bookmarksCache);
        } else {
            JavaChromeApi.getBookmarks().then((list) => {
                bookmarksCache = list;
                render(list);
            });
        }
    }

    return {
        init,
        onActiveTabChanged,
        initNewTabPage,
        showBlockedBanner,
        hideBlockedBanner,
    };
})();

document.addEventListener('DOMContentLoaded', BrowserChrome.init);
