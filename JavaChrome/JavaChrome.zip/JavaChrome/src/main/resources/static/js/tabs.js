/**
 * Gerenciador de abas do JavaChrome.
 *
 * Cada aba mantem sua PROPRIA pilha de historico (historyStack/historyIndex).
 * A navegacao do iframe NAO aponta direto para o site externo: ela passa
 * pelo endpoint "/proxy/view?url=..." do backend, que busca a pagina no
 * servidor e a devolve hospedada no dominio do JavaChrome. Isso e o que
 * permite exibir sites que bloqueiam ser enquadrados por outra origem
 * (X-Frame-Options / CSP frame-ancestors) - ver ProxyService no backend.
 *
 * Um efeito colateral bom dessa abordagem: como o iframe passa a ser
 * "same-origin" com a nossa propria aplicacao, conseguimos ler
 * iframe.contentWindow.location com seguranca para saber para qual URL o
 * usuario navegou ao clicar em um link DENTRO da pagina proxiada (algo que
 * seria impossivel se o iframe apontasse direto para o site externo).
 */
const TabManager = (() => {

    let nextId = 1;
    const tabs = new Map();
    let activeTabId = null;

    const tabbarEl = document.getElementById('tabbar');
    const contentEl = document.getElementById('content');
    const tabTemplate = document.getElementById('tab-template');
    const viewTemplate = document.getElementById('view-template');

    function proxyUrlFor(realUrl) {
        return '/proxy/view?url=' + encodeURIComponent(realUrl);
    }

    function createTab(initialUrl) {
        const id = nextId++;

        const tabEl = tabTemplate.content.firstElementChild.cloneNode(true);
        tabEl.dataset.tabId = id;
        tabbarEl.insertBefore(tabEl, document.getElementById('new-tab-btn'));

        const viewEl = viewTemplate.content.firstElementChild.cloneNode(true);
        viewEl.dataset.tabId = id;
        contentEl.appendChild(viewEl);

        const tab = {
            id,
            url: '',
            title: 'Nova aba',
            favicon: '',
            historyStack: [],
            historyIndex: -1,
            tabEl,
            viewEl,
            iframeEl: viewEl.querySelector('iframe'),
            newtabEl: viewEl.querySelector('.jc-newtab'),
        };
        tabs.set(id, tab);

        tabEl.querySelector('.jc-tab-close').addEventListener('click', (evt) => {
            evt.stopPropagation();
            closeTab(id);
        });
        tabEl.addEventListener('click', () => activateTab(id));

        tab.iframeEl.addEventListener('load', () => onIframeLoad(tab));

        BrowserChrome.initNewTabPage(tab);

        activateTab(id);
        if (initialUrl) {
            navigate(id, initialUrl);
        } else {
            showNewTabPage(tab);
        }

        return tab;
    }

    function closeTab(id) {
        const tab = tabs.get(id);
        if (!tab) return;

        tab.tabEl.remove();
        tab.viewEl.remove();
        tabs.delete(id);

        if (tabs.size === 0) {
            createTab();
            return;
        }

        if (activeTabId === id) {
            const remaining = Array.from(tabs.keys());
            activateTab(remaining[remaining.length - 1]);
        }
    }

    function activateTab(id) {
        if (activeTabId !== null && tabs.has(activeTabId)) {
            tabs.get(activeTabId).tabEl.classList.remove('active');
            tabs.get(activeTabId).viewEl.classList.remove('active');
        }
        activeTabId = id;
        const tab = tabs.get(id);
        tab.tabEl.classList.add('active');
        tab.viewEl.classList.add('active');

        BrowserChrome.onActiveTabChanged(tab);
    }

    function getActiveTab() {
        return tabs.get(activeTabId);
    }

    function showNewTabPage(tab) {
        tab.url = '';
        tab.title = 'Nova aba';
        tab.favicon = '';
        tab.iframeEl.removeAttribute('src');
        tab.newtabEl.classList.add('active');
        renderTabLabel(tab);
        BrowserChrome.hideBlockedBanner();
        if (activeTabId === tab.id) {
            BrowserChrome.onActiveTabChanged(tab);
        }
    }

    /**
     * Navega a aba para uma URL (sempre via "/proxy/view"). Por padrao,
     * empilha a URL no historico proprio da aba (usado por Voltar/Avancar).
     */
    function navigate(id, url, { pushHistory = true } = {}) {
        const tab = tabs.get(id);
        if (!tab) return;

        if (!url) {
            showNewTabPage(tab);
            return;
        }

        tab.newtabEl.classList.remove('active');
        tab.url = url;
        tab.title = safeHostname(url);
        tab.iframeEl.src = proxyUrlFor(url);

        if (pushHistory) {
            tab.historyStack = tab.historyStack.slice(0, tab.historyIndex + 1);
            tab.historyStack.push(url);
            tab.historyIndex = tab.historyStack.length - 1;
        }

        renderTabLabel(tab);
        BrowserChrome.hideBlockedBanner();
        if (activeTabId === id) {
            BrowserChrome.onActiveTabChanged(tab);
        }
    }

    function goBack(id) {
        const tab = tabs.get(id);
        if (!tab || tab.historyIndex <= 0) return;
        tab.historyIndex -= 1;
        navigate(id, tab.historyStack[tab.historyIndex], { pushHistory: false });
    }

    function goForward(id) {
        const tab = tabs.get(id);
        if (!tab || tab.historyIndex >= tab.historyStack.length - 1) return;
        tab.historyIndex += 1;
        navigate(id, tab.historyStack[tab.historyIndex], { pushHistory: false });
    }

    function reload(id) {
        const tab = tabs.get(id);
        if (!tab || !tab.url) return;
        // acrescenta um parametro sem uso para evitar cache do proprio navegador
        tab.iframeEl.src = proxyUrlFor(tab.url) + '&_t=' + Date.now();
    }

    function canGoBack(tab) {
        return tab.historyIndex > 0;
    }

    function canGoForward(tab) {
        return tab.historyIndex < tab.historyStack.length - 1;
    }

    function renderTabLabel(tab) {
        tab.tabEl.querySelector('.jc-tab-title').textContent = tab.title;
        const faviconEl = tab.tabEl.querySelector('.jc-tab-favicon');
        faviconEl.style.backgroundImage = tab.favicon ? `url("${tab.favicon}")` : 'none';
    }

    function safeHostname(url) {
        try {
            return new URL(url).hostname;
        } catch (e) {
            return url;
        }
    }

    /**
     * Chamado a cada "load" do iframe: acontece na navegacao inicial, no
     * reload, e tambem quando o usuario clica em um link REESCRITO dentro
     * da pagina proxiada (o link aponta de volta para "/proxy/view?url=",
     * entao o iframe recarrega e este evento dispara de novo).
     */
    function onIframeLoad(tab) {
        if (!tab.url) return;

        let realUrl = tab.url;
        let isErrorPage = false;

        try {
            const doc = tab.iframeEl.contentDocument;
            isErrorPage = !!(doc && doc.documentElement
                && doc.documentElement.hasAttribute('data-jc-proxy-error'));

            const iframeHref = tab.iframeEl.contentWindow.location.href;
            const currentUrlParam = new URL(iframeHref).searchParams.get('url');
            if (currentUrlParam) {
                realUrl = currentUrlParam; // URLSearchParams ja decodifica
            }
        } catch (e) {
            // Nao deveria acontecer (iframe agora e same-origin), mas seguimos
            // com o valor de tab.url que ja tinhamos por seguranca.
        }

        if (isErrorPage) {
            BrowserChrome.showBlockedBanner();
            return;
        }

        // O usuario pode ter navegado clicando em um link DENTRO da pagina
        // proxiada; sincronizamos o estado da aba com a pagina atual.
        if (realUrl !== tab.url) {
            tab.url = realUrl;
            tab.historyStack = tab.historyStack.slice(0, tab.historyIndex + 1);
            tab.historyStack.push(realUrl);
            tab.historyIndex = tab.historyStack.length - 1;
            tab.title = safeHostname(realUrl);
            renderTabLabel(tab);
            if (activeTabId === tab.id) {
                BrowserChrome.onActiveTabChanged(tab);
            }
        }

        JavaChromeApi.fetchMetadata(realUrl)
            .then((meta) => {
                tab.title = meta.title || tab.title;
                tab.favicon = meta.faviconUrl || tab.favicon;
                renderTabLabel(tab);
                if (activeTabId === tab.id) {
                    BrowserChrome.onActiveTabChanged(tab);
                }
                return JavaChromeApi.addHistory({
                    title: tab.title,
                    url: realUrl,
                    faviconUrl: tab.favicon,
                });
            })
            .catch((err) => console.warn('Nao foi possivel atualizar metadados da aba:', err));
    }

    return {
        createTab,
        closeTab,
        activateTab,
        navigate,
        goBack,
        goForward,
        reload,
        canGoBack,
        canGoForward,
        getActiveTab,
    };
})();
