/**
 * Logica da pagina completa de favoritos (/bookmarks).
 * A remocao e feita via AJAX para nao precisar recarregar a pagina inteira.
 */
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-remove-bookmark]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.removeBookmark;
            const item = btn.closest('.jc-list-item');

            if (!confirm('Remover este favorito?')) return;

            JavaChromeApi.removeBookmark(id)
                .then(() => {
                    item.remove();
                    updateEmptyState();
                })
                .catch((err) => alert('Erro ao remover favorito: ' + err.message));
        });
    });

    function updateEmptyState() {
        const list = document.getElementById('bookmarks-list');
        if (list && list.children.length === 0) {
            document.getElementById('empty-state').style.display = 'block';
        }
    }
});
